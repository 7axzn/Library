

from django.contrib import admin
from .models import Book_Details, CustomUser

admin.site.register(Book_Details)
admin.site.register(CustomUser)
