# Library
This Django-based Library Management System allows users to browse and borrow books, while admins can add, edit, and delete book records. It features user and admin dashboards, search functionality, and a clean, simple interface styled with CSS. Designed for easy expansion and learning purposes.
